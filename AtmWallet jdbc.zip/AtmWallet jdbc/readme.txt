create table wallet(
username varchar2(30),
password varchar2(30),
balance number(10,2)
 );
 
 
 
create table transaction(
username varchar2(30),
 type varchar2(2),
 amount number(20),
 fbalance number(10,2),
 d varchar2(40)
 );
 
 //
 private String userName;
	private String type;
	private double amount;
	private double fbalance;
	private LocalDateTime d;